/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_TORCH_ADPT_H
#define KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_TORCH_ADPT_H

namespace vllm_ascend {

namespace {

std::tuple<at::Tensor, at::Tensor, at::Tensor>
construct_kv_quant_sparse_flash_attention_vllm_output_tensor(
    const at::Tensor &query,
    const at::Tensor &key,
    const std::string &layout_query_str,
    const std::string &layout_kv_str,
    int64_t rope_head_dim,
    bool return_softmax_lse)
{
    constexpr int64_t SIZE = 8;
    constexpr int64_t DIM_0 = 0;
    constexpr int64_t DIM_1 = 1;
    constexpr int64_t DIM_2 = 2;
    constexpr int64_t DIM_3 = 3;
    constexpr int64_t DIM_4 = 4;

    TORCH_CHECK(layout_query_str == "BSND" || layout_query_str == "TND",
                "The layout of query only support BSND and TND, but got ",
                layout_query_str);
    for (size_t i = 0; i < query.sizes().size(); i++) {
        TORCH_CHECK(query.size(i) > 0,
                    "All values within query's shape should be greater than 0, but shape[",
                    i, "] is ", query.size(i));
    }

    at::SmallVector<int64_t, SIZE> output_size;
    if (layout_query_str == "BSND") {
        TORCH_CHECK(query.dim() == DIM_4,
                    "When the layout of query is BSND, the query dimension must be 4, but got ",
                    query.dim());
        output_size = {query.size(DIM_0), query.size(DIM_1), query.size(DIM_2),
                       query.size(DIM_3) - rope_head_dim};
    } else {
        TORCH_CHECK(query.dim() == DIM_3,
                    "When the layout of query is TND, the query dimension must be 3, but got ",
                    query.dim());
        output_size = {query.size(DIM_0), query.size(DIM_1),
                       query.size(DIM_2) - rope_head_dim};
    }

    at::Tensor attention_output =
        at::empty(output_size, query.options().dtype(query.dtype()));
    at::SmallVector<int64_t, SIZE> softmax_size;
    if (return_softmax_lse) {
        if (query.dim() == DIM_3) {
            const int64_t kv_head_dim =
                layout_kv_str == "PA_BSND" ? key.size(DIM_2) : key.size(DIM_1);
            softmax_size = {kv_head_dim, query.size(DIM_0),
                            query.size(DIM_1) / kv_head_dim};
        } else {
            softmax_size = {query.size(DIM_0), key.size(DIM_2),
                            query.size(DIM_1),
                            query.size(DIM_2) / key.size(DIM_2)};
        }
    } else {
        softmax_size = {0};
    }

    at::Tensor softmax_max =
        at::empty(softmax_size, query.options().dtype(at::kFloat));
    at::Tensor softmax_sum =
        at::empty(softmax_size, query.options().dtype(at::kFloat));
    return std::tuple<at::Tensor, at::Tensor, at::Tensor>(
        attention_output, softmax_max, softmax_sum);
}

}  // namespace

std::tuple<at::Tensor, at::Tensor, at::Tensor>
npu_kv_quant_sparse_flash_attention_vllm(
    const at::Tensor &query,
    const at::Tensor &key,
    const at::Tensor &value,
    const at::Tensor &sparse_indices,
    double scale_value,
    int64_t key_quant_mode,
    int64_t value_quant_mode,
    const c10::optional<at::Tensor> &key_dequant_scale,
    const c10::optional<at::Tensor> &value_dequant_scale,
    const c10::optional<at::Tensor> &block_table,
    const c10::optional<at::Tensor> &actual_seq_lengths_query,
    const c10::optional<at::Tensor> &actual_seq_lengths_kv,
    int64_t sparse_block_size,
    c10::string_view layout_query,
    c10::string_view layout_kv,
    int64_t sparse_mode,
    int64_t pre_tokens,
    int64_t next_tokens,
    int64_t attention_mode,
    int64_t quant_scale_repo_mode,
    int64_t tile_size,
    int64_t rope_head_dim,
    bool return_softmax_lse)
{
    TORCH_CHECK(query.numel() > 0, "Tensor query is empty.");
    TORCH_CHECK(key.numel() > 0, "Tensor key is empty.");
    TORCH_CHECK(value.numel() > 0, "Tensor value is empty.");
    TORCH_CHECK(sparse_indices.numel() > 0, "Tensor sparse_indices is empty.");

    std::string layout_query_str = std::string(layout_query);
    std::string layout_kv_str = std::string(layout_kv);

    auto output = construct_kv_quant_sparse_flash_attention_vllm_output_tensor(
        query, key, layout_query_str, layout_kv_str, rope_head_dim,
        return_softmax_lse);
    at::Tensor attention_output = std::get<0>(output);
    at::Tensor softmax_max = std::get<1>(output);
    at::Tensor softmax_sum = std::get<2>(output);

    char *layout_query_ptr = const_cast<char *>(layout_query_str.c_str());
    char *layout_kv_ptr = const_cast<char *>(layout_kv_str.c_str());

    EXEC_NPU_CMD(
        aclnnKvQuantSparseFlashAttentionVllm,
        query,
        key,
        value,
        sparse_indices,
        key_dequant_scale,
        value_dequant_scale,
        block_table,
        actual_seq_lengths_query,
        actual_seq_lengths_kv,
        scale_value,
        key_quant_mode,
        value_quant_mode,
        sparse_block_size,
        layout_query_ptr,
        layout_kv_ptr,
        sparse_mode,
        pre_tokens,
        next_tokens,
        attention_mode,
        quant_scale_repo_mode,
        tile_size,
        rope_head_dim,
        return_softmax_lse,
        attention_output,
        softmax_max,
        softmax_sum);
    return std::tuple<at::Tensor, at::Tensor, at::Tensor>(
        attention_output, softmax_max, softmax_sum);
}
}  // namespace vllm_ascend

#endif  // KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_TORCH_ADPT_H
