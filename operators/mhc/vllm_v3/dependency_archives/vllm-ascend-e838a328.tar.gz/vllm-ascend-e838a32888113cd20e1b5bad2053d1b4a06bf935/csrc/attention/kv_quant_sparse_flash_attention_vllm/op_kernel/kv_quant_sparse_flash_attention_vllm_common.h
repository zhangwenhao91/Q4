/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*!
 * \file kv_quant_sparse_flash_attention_vllm_common.h
 * \brief
 */

#ifndef KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_COMMON_H
#define KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_COMMON_H

#include "kernel_operator.h"
#include "lib/matmul_intf.h"
#include "lib/matrix/matmul/tiling.h"

using namespace AscendC;
// 将isCheckTiling设置为false, 输入输出的max&sum&exp的shape为(m, 1)
constexpr SoftmaxConfig QSFA_SOFTMAX_FLASHV2_CFG_WITHOUT_BRC = {false, 0, 0, SoftmaxMode::SOFTMAX_OUTPUT_WITHOUT_BRC};

enum class QSFA_LAYOUT {
    BSND = 0,
    TND = 1,
    PA_BSND = 2,
};

enum class QUANT_MODE {
    PER_CHANNEL = 0,  // GQA支持
    PER_TOKEN_HEAD = 1, // GQA支持
    PER_TILE = 2,   // MLA支持
};

enum class ATTENTION_MODE {
    GQA_MHA = 0,  // QKV headDim相等
    MLA_NATIVE = 1, // Dn=128, Dr=64
    MLA_ABSORB = 2,   // Dn=512, Dr=64
};

enum class QUANT_SCALE_REPO_MODE {
    SEPARATE = 0,  // 分开存储
    COMBINE = 1, // 合并存储，量化模式是PER_TOKEN_HEAD/PER_TILE时支持COMBINE模式，参数顺序为：Nope+Rope+DequantScale
};

template <typename Q_T, typename KV_T, typename OUT_T, const bool FLASH_DECODE = false,
	  QSFA_LAYOUT LAYOUT_T = QSFA_LAYOUT::BSND, QSFA_LAYOUT KV_LAYOUT_T = QSFA_LAYOUT::BSND,
          const int TEMPLATE_MODE = C_TEMPLATE, const bool NO_ROPE = false, typename... Args>
struct QSFAType {
    using queryType = Q_T;
    using kvType = KV_T;
    using kRopeType = Q_T;
    using outputType = OUT_T;
    static constexpr bool flashDecode = FLASH_DECODE;
    static constexpr bool noRope = NO_ROPE;
    static constexpr bool adaptiveAddresses = false;
    static constexpr QSFA_LAYOUT layout = LAYOUT_T;
    static constexpr QSFA_LAYOUT kvLayout = KV_LAYOUT_T;
    static constexpr int templateMode = TEMPLATE_MODE;
    static constexpr bool pageAttention = (KV_LAYOUT_T == QSFA_LAYOUT::PA_BSND);
};

// Internal specialization only; public template keys and small-table types stay unchanged.
template <typename BaseType>
struct QSFAAdaptiveAddressType : BaseType {
    static constexpr bool adaptiveAddresses = true;
};

template <typename BaseType, bool UseLargeTable>
struct QSFAAddressTableType {
    using type = BaseType;
};

template <typename BaseType>
struct QSFAAddressTableType<BaseType, true> {
    using type = QSFAAdaptiveAddressType<BaseType>;
};

// ================================Util functions==================================
template <typename T> __aicore__ inline T QSFAAlign(T num, T rnd)
{
    return (((rnd) == 0) ? 0 : (((num) + (rnd) - 1) / (rnd) * (rnd)));
}

template <typename T> __aicore__ inline size_t BlockAlign(size_t s)
{
    if constexpr (IsSameType<T, int4b_t>::value) {
        return (s + 63) / 64 * 64;
    }
    size_t n = (32 / sizeof(T));
    return (s + n - 1) / n * n;
}

template <typename T1, typename T2> __aicore__ inline T1 Min(T1 a, T2 b)
{
    return (a > b) ? (b) : (a);
}

struct RunInfo {
    uint32_t loop;
    uint32_t bIdx;
    uint32_t gIdx;
    uint32_t s1Idx;
    uint32_t s2Idx;
    uint32_t bn2IdxInCurCore;
    uint32_t curSInnerLoopTimes;
    uint32_t s2BatchOffset;

    uint64_t tndBIdxOffsetForQ;
    uint64_t tndBIdxOffsetForKV;
    uint64_t tensorAOffset;
    uint64_t tensorBOffset;
    uint64_t tensorARopeOffset;
    uint64_t tensorBRopeOffset;
    uint64_t attenOutOffset;
    uint64_t topKBaseOffset;
    uint64_t attenMaskOffset;

    uint32_t actualSingleProcessSInnerSize;
    uint32_t actualSingleProcessSInnerSizeAlign;
    uint32_t gSize;
    uint32_t s1Size;
    uint32_t s2Size;
    uint32_t mSize;
    uint32_t mSizeV;
    uint32_t mSizeVStart;
    uint32_t tndIsS2SplitCore;
    uint32_t tndCoreStartKVSplitPos;
    bool isBmm2Output;
    bool isValid = false;
    bool isFirstSInnerLoop;
    bool isChangeBatch;
    static constexpr uint32_t n2Idx = 0;

    uint64_t actS1Size = 1;
    uint64_t curActualSeqLenOri = 0ULL;
    uint64_t actS2Size = 1;

    uint32_t gS1Idx;
    uint32_t actMBaseSize;
    int32_t nextTokensPerBatch = 0;
    bool isLastS2Loop;
    uint8_t resv[3];
    int64_t threshold;
};

struct ConstInfo {
    // CUBE与VEC核间同步的模式
    static constexpr uint32_t QSFA_SYNC_MODE2 = 2;
    // BUFFER的字节数
    static constexpr uint32_t BUFFER_SIZE_BYTE_1K = 1024;
    static constexpr uint32_t BUFFER_SIZE_BYTE_2K = 2048;
    static constexpr uint32_t BUFFER_SIZE_BYTE_4K = 4096;
    static constexpr uint32_t BUFFER_SIZE_BYTE_8K = 8192;
    static constexpr uint32_t BUFFER_SIZE_BYTE_16K = 16384;
    static constexpr uint32_t BUFFER_SIZE_BYTE_32K = 32768;
    static constexpr uint32_t BUFFER_SIZE_BYTE_32B = 32;
    static constexpr uint32_t BUFFER_SIZE_BYTE_64B = 64;
    static constexpr uint32_t BUFFER_SIZE_BYTE_256B = 256;
    static constexpr uint32_t BUFFER_SIZE_BYTE_512B = 512;
    // FP32的0值和极大值
    static constexpr float FLOAT_ZERO = 0;
    static constexpr float FLOAT_MAX = 3.402823466e+38F;

    // preLoad的总次数
    uint32_t preLoadNum = 0U;
    uint32_t nBufferMBaseSize = 0U;
    // CUBE和VEC的核间同步EventID
    uint32_t syncV0C1 = 0U;
    uint32_t syncC1V1 = 0U;
    uint32_t syncV1C2 = 0U;
    uint32_t syncC2V2 = 0U;
    uint32_t syncC2V1 = 0U;
    uint32_t syncV1NupdateC2 = 0U;

    uint32_t mmResUbSize = 0U;   // Matmul1输出结果GM上的大小
    uint32_t vec1ResUbSize = 0U; // Vector1输出结果GM上的大小
    uint32_t bmm2ResUbSize = 0U; // Matmul2输出结果GM上的大小
    uint64_t gSize = 0ULL;
    uint64_t batchSize = 0ULL;
    uint64_t qHeadNum = 0ULL;
    uint64_t kvHeadNum;
    uint64_t headDim;
    uint64_t headDimRope;      // Internal RoPE width retained for the 576-wide Cube path.
    uint64_t inputHeadDimRope; // Actual RoPE width in GM: 0 or 64.
    uint64_t combineHeadDim;   // Actual query row width in GM.
    uint64_t kvSeqSize = 0ULL;        // kv最大S长度
    uint64_t qSeqSize = 1ULL;         // q最大S长度
    int64_t kvCacheBlockSize = 0;    // PA场景的block size
    uint32_t maxBlockNumPerBatch = 0; // PA场景的最大单batch block number
    uint32_t splitKVNum = 0U;         // S2核间切分的切分份数
    QSFA_LAYOUT outputLayout;          // 输出的Transpose格式
    uint32_t sparseMode = 0;
    bool returnSoftmaxLse = false;
    bool needInit = false;

    // FlashDecoding
    uint64_t combineLseOffset = 0ULL;
    uint64_t combineAccumOutOffset = 0ULL;
    uint32_t actualCombineLoopSize = 0U; // FlashDecoding场景, S2在核间切分的最大份数

    uint32_t actualLenDimsQ = 0U;   // query的actualSeqLength 的维度
    uint32_t actualLenDimsKV = 0U;  // KV 的actualSeqLength 的维度

    // TND
    uint32_t s2Start = 0U; // TND场景下，S2的起始位置
    uint32_t s2End = 0U;   // 单核TND场景下S2循环index上限

    uint32_t bN2Start = 0U;
    uint32_t bN2End = 0U;
    uint32_t gS1Start = 0U;
    uint32_t gS1End = 0U;

    uint32_t mBaseSize = 1ULL;
    uint32_t s2BaseSize = 1ULL;

    uint32_t tndFDCoreArrLen = 0U;     // TNDFlashDecoding相关分核信息array的长度
    uint32_t coreStartKVSplitPos = 0U; // TNDFlashDecoding kv起始位置

    // sparse attr
    uint32_t sparseBlockCount = 0;
    int64_t sparseBlockSize = 0;

    // attention模式与量化模式
    ATTENTION_MODE attentionMode = ATTENTION_MODE::MLA_ABSORB;
    QUANT_MODE keyQuantMode = QUANT_MODE::PER_TILE;
    QUANT_MODE valueQuantMode = QUANT_MODE::PER_TILE;
    QUANT_SCALE_REPO_MODE quantScaleRepoMode = QUANT_SCALE_REPO_MODE::COMBINE;
    uint64_t tileSize = 128ULL;
};

struct MSplitInfo {
    uint32_t nBufferIdx = 0U;
    uint32_t nBufferStartM = 0U;
    uint32_t nBufferDealM = 0U;
    uint32_t vecStartM = 0U;
    uint32_t vecDealM = 0U;
};

#endif // KV_QUANT_SPARSE_FLASH_ATTENTION_VLLM_COMMON_H