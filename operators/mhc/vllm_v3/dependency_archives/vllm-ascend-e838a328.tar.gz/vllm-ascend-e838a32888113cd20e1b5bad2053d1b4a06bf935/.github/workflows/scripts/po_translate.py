#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#

import argparse
import asyncio
import json
import os
import shutil
import sys
import time
from pathlib import Path

import regex as re
import zhconv
from openai import AsyncOpenAI
from polib import POEntry, pofile

SYSTEM_PROMPT = (
    "You are a professional technical documentation translator specializing in "
    "translating MkDocs markdown documentation from English to Simplified Chinese (简体中文). "
    "You produce accurate, consistent translations of all gettext PO file entries "
    "without skipping any. You never add explanations, markdown fences, or extra text "
    "outside the PO file content."
    "TERMINOLOGY RULE (MUST FOLLOW):"
    "- The standalone word 'Ascend' (Huawei's NPU brand) MUST be translated to '昇腾' (Simplified Chinese brand name)."
    "NEVER translate it to '升腾'."
    "- The compound name 'vLLM Ascend' (the project name) MUST be kept in English verbatim as 'vLLM Ascend'."
    "Do NOT translate it to 'vLLM 昇腾' or 'vLLM 升腾'."
    "- Same for 'vllm-ascend' (the package/repo name): keep it verbatim in English."
    "- Other brand/product names (vLLM, CANN, Huawei, Atlas) MUST be kept in English verbatim."
    "PRODUCT-LINE NAMING RULE (MUST FOLLOW EXACTLY, including spaces):"
    "- '950PR&950DT Products'  -> 'Ascend 950PR&950DT系列产品'"
    "- '950DT Products'        -> 'Ascend 950DT系列产品'"
    "- '950PR Products'        -> 'Ascend 950PR系列产品'"
    "- 'Atlas A2 Products'     -> 'Atlas A2系列产品'"
    "- 'Atlas A3 Products'     -> 'Atlas A3系列产品'"
    "IMPORTANT: In all five cases there MUST be NO space between the model"
    "number (e.g. '950DT', 'A2', 'A3') and '系列产品'. The '&' in '950PR&950DT'"
    "has NO surrounding spaces. Do NOT output '950DT 系列产品' (with a space) or '950DT系列 产品' (split)."
)

TRANSLATION_PROMPT = """Translate these PO file entries (gettext format) from English to Simplified Chinese (简体中文).

You are given a list of msgid/msgstr pairs where every msgstr is empty ("").
For each msgid, fill in the Chinese translation in the corresponding msgstr.

This content comes from MkDocs (Material for Mkdocs) markdown documentation
for the vLLM Ascend project (an NPU hardware plugin for vLLM). The documentation
covers installation, user guides, developer guides, and API references.

CRITICAL RULES — violations will cause the translation to be rejected:

--- OUTPUT FORMAT ---
1. Return ONLY the same list of msgid/msgstr pairs with msgstr filled in.
   No markdown code fences (```), no explanations, no summaries, no greetings.
2. The number of entries in your output MUST EQUAL the number in the input.
   Count them: if you received N entries, you must return exactly N entries.
   Do NOT drop, merge, split, reorder, or add entries under any circumstance.
3. Keep msgid lines COMPLETELY UNCHANGED — copy them exactly as-is from input.
   NEVER change `msgid ""` to anything else (not `msgstr ""`, not `msgid "..."`).
   Multi-line entries start with `msgid ""` — that is NOT a typo, keep it.

--- WHAT TO PRESERVE (keep EXACTLY as in msgid) ---
4. All format specifiers: %s, %d, %f, {{}}, {{{{}}}}, {{name}}, etc.
5. All markdown syntax MUST be preserved exactly:
   - Headings: "#", "##", "###", etc. at the start of a line
   - Bold/italic: **bold**, *italic*
   - Inline code: `code`
   - Code blocks: ```code blocks```
   - Links: [text](url), ![images](url)
   - List markers: "- ", "* ", "1. ", "2. " at the start of each list item
   - Blockquotes: "> "
   - Tables: | columns |, separator rows (|:---:|)
   - Horizontal rules: ---
6. HTML tags and attributes: <div>, <a href>, <img>, etc.
7. Environment variables, file paths, command names, code identifiers.
8. Proper nouns: person names, contributor names, author names, company names,
   product/project/package names:
   - 'vLLM Ascend' → 'vLLM Ascend'
   - 'vllm-ascend' → 'vllm-ascend'
   - vLLM, CANN, Huawei, Atlas, etc..

--- CONTENT THAT SHOULD NOT BE TRANSLATED ---
9. DO NOT translate contributor names, GitHub usernames, or dates.
   These should be copied verbatim from msgid to msgstr.
   Example: "Xiyuan Wang [@wangxiyuan] 2025-01-15" → keep as-is.

10. DO NOT translate table headers or table separator rows that are purely
    structural. Copy them verbatim.
    Example: "| Name | GitHub ID | Date |" → keep as-is.
    Example: "|:-----------:|:-----:|:-----:|" → keep as-is.

11. DO NOT translate code identifiers, variable names, CLI flags, or shell
    commands. Copy them verbatim.
    Example: "--data-parallel-size" → keep as-is.
    Example: "vllm serve /path/to/model" → keep as-is.

12. DO NOT translate URLs, email addresses, or paths.
    Copy them verbatim from msgid to msgstr.

--- TERMINOLOGY (MUST TRANSLATE) ---

13. standalone 'Ascend' → '昇腾'
14. '950PR&950DT Products' → 'Ascend 950PR&950DT系列产品'
15. '950DT Products'       → 'Ascend 950DT系列产品'
16. '950PR Products'       → 'Ascend 950PR系列产品'
17. 'Atlas A2 Products'    → 'Atlas A2系列产品'
18. 'Atlas A3 Products'    → 'Atlas A3系列产品'

--- MkDocs MATERIAL EXTENSIONS ---
19. ADMONITIONS (!!! type): Keep "!!!" and type keyword (note, warning, tip)
    in English. Only translate the title text after type.
    Example: msgid "!!! note" → msgstr "!!! note"
    Example: msgid "!!! note \"Important\"" → msgstr "!!! note \"重要\""

20. COLLAPSIBLE BLOCKS (??? type / ???+ type): Keep the exact "???" or
    "???+" marker, the type keyword, and quote syntax unchanged. The "+"
    means expanded by default and MUST NOT be added or removed. Translate only
    the title text inside quotes.
    Example: msgid "??? note \\"Click here...\\"" → msgstr "??? note \\"点击这里...\\""
    Example: msgid "???+ warning \\"Important\\"" → msgstr "???+ warning \\"重要\\""

21. CONTENT TABS (===): Keep "===" and quote syntax. Translate only the label.
    Example: msgid "=== \"Before using pip\"" → msgstr "=== \"使用pip之前\""



--- TRANSLATION QUALITY ---
22. Use natural, fluent Chinese technical documentation style. Avoid word-by-word
    literal translation.
23. Use standard Chinese technical terminology consistently.
24. For markdown links [text](url): translate the display text in [] but keep
    the URL in () exactly as-is.
    Example: [Quick Start](quick_start.md) → [快速开始](quick_start.md)
25. For headings: translate the heading text but KEEP the "#" / "##" / "###"
    prefix exactly as in the msgid.
    Example: msgid "# Quick Start" → msgstr "# 快速开始"
    Example: msgid "## Overview" → msgstr "## 概述"
26. DO NOT add "#, fuzzy" markers.
27. If a msgid is purely structural (symbols, code, file paths only), copy it
    verbatim to msgstr.
28. Never invent or guess content. If unsure about a term, leave it in English.

{content}"""

_SIMPLIFIED_CONVERSION_PROTECTED_TERMS = ("昇腾",)


def _normalize_msgid(text: str) -> str:
    """Normalize a msgid for fuzzy comparison.

    Strips trailing whitespace from each line, removes trailing blank lines,
    and collapses trailing spaces within each line.  This handles common
    API-induced differences like trailing spaces or extra blank lines, while
    preserving the line structure needed for correct matching.
    """
    lines = [line.rstrip() for line in text.split("\n")]
    # Remove trailing empty lines.
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


def _convert_po_to_simplified(po):
    """Convert all msgstr values in a PO file from Traditional to Simplified Chinese.

    This is a safety net to catch any Traditional Chinese characters that the
    translation model may have produced despite the prompt requesting Simplified
    Chinese only. Preserve configured terms during conversion, including
    spellings such as ``昇腾`` that zhconv would otherwise normalize to ``升腾``.
    """
    for entry in po:
        if entry.msgstr:
            protected = entry.msgstr
            placeholders = []
            for index, term in enumerate(_SIMPLIFIED_CONVERSION_PROTECTED_TERMS):
                placeholder = f"__VLLM_DOC_PROTECTED_TERM_{index}__"
                protected = protected.replace(term, placeholder)
                placeholders.append((placeholder, term))
            converted = zhconv.convert(protected, "zh-cn")
            for placeholder, term in placeholders:
                converted = converted.replace(placeholder, term)
            entry.msgstr = converted


class POTranslator:
    def __init__(self, api_key: str, max_concurrent: int = 5):
        self.client = AsyncOpenAI(api_key=api_key, base_url="https://api.deepseek.com")
        self.max_concurrent = max_concurrent

    async def _call_api(self, content: str, chunk_info: str = "") -> str | None:
        prompt = TRANSLATION_PROMPT.format(content=content)
        system = SYSTEM_PROMPT
        if chunk_info:
            system = f"{SYSTEM_PROMPT} ({chunk_info})"
        response = await self.client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            max_tokens=8000,
            temperature=0.3,
        )
        text = response.choices[0].message.content
        if not text:
            return None
        cleaned = self._clean_response(text)
        return cleaned if cleaned else None  # empty means retry needed

    async def translate_file(self, po_path: str) -> bool:
        path = Path(po_path)
        if not path.exists() or path.suffix != ".po":
            print(f"  Skip: {po_path} (not found or not .po)")
            return False

        backup = po_path + ".bak"
        shutil.copy2(po_path, backup)

        try:
            po = pofile(str(path))
            untranslated = [entry for entry in po if entry.msgid and not entry.msgstr and not entry.obsolete]
            if not untranslated:
                print(f"  {path.name} (0 untranslated, skip)", flush=True)
                return True

            total_entries = len([e for e in po if e.msgid and not e.obsolete])
            print(
                f"  {path.name} ({len(untranslated)}/{total_entries} untranslated)",
                end=" ",
                flush=True,
            )

            # Build a minimal PO snippet with only untranslated entries.
            snippet = self._build_snippet(untranslated)
            chunks = self._split_entries(snippet)
            if len(chunks) > 1:
                translated_chunks = await self._translate_chunks(chunks)
                if translated_chunks is None:
                    shutil.copy2(backup, po_path)
                    print("FAILED (all chunks)")
                    return False
                # Filter out failed chunks (None values).
                successful = [c for c in translated_chunks if c is not None]
                if not successful:
                    shutil.copy2(backup, po_path)
                    print("FAILED (no successful chunks)")
                    return False
                if len(successful) < len(chunks):
                    print(
                        f"({len(successful)}/{len(chunks)} chunks succeeded)",
                        end=" ",
                        flush=True,
                    )
                # Merge each chunk individually — one malformed chunk
                # won't block the rest.
                total_merged = 0
                for chunk_result in successful:
                    try:
                        chunk_po = pofile(chunk_result)
                    except Exception:
                        continue
                    chunk_map: dict[str, str] = {}
                    for entry in chunk_po:
                        if entry.msgid and entry.msgstr:
                            chunk_map[entry.msgid] = entry.msgstr
                    for entry in untranslated:
                        if entry.msgid in chunk_map:
                            entry.msgstr = chunk_map[entry.msgid]
                            total_merged += 1
                        else:
                            matched = POTranslator._fuzzy_match(entry.msgid, chunk_map)
                            if matched is not None:
                                entry.msgstr = chunk_map[matched]
                                total_merged += 1
                merged = total_merged
            else:
                translated_snippet = await self._call_api(snippet)
                if translated_snippet is None:
                    shutil.copy2(backup, po_path)
                    print("FAILED")
                    return False
                merged = self._merge_translations(po, untranslated, translated_snippet)

            if merged == 0:
                shutil.copy2(backup, po_path)
                print("FAILED (merge)")
                return False

            _convert_po_to_simplified(po)
            po.save(str(path))
            if merged < len(untranslated):
                print(f"OK ({merged}/{len(untranslated)} merged)")
            else:
                print("OK")
            return True
        except Exception as e:
            print(f"ERROR: {e}")
            shutil.copy2(backup, po_path)
            return False
        finally:
            Path(backup).unlink(missing_ok=True)

    @staticmethod
    def _build_snippet(entries: list[POEntry]) -> str:
        """Build a minimal PO content string containing only *entries*.

        Multi-line msgid values are collapsed into single-line format with
        literal ``\\n`` escapes so that the API does not try to "translate"
        the msgid continuation-line structure itself (which would corrupt the
        PO format and make round-trip parsing impossible).
        """
        parts = []
        for entry in entries:
            lines = entry.msgid.split("\n")
            if len(lines) == 1:
                escaped = entry.msgid.replace("\\", "\\\\").replace('"', '\\"')
                parts.append(f'msgid "{escaped}"\nmsgstr ""')
            else:
                # Collapse multi-line msgid into a single line with
                # literal \n escapes so the API treats it as one unit.
                collapsed = entry.msgid.replace("\\", "\\\\").replace('"', '\\"')
                # Replace actual newlines with literal \n in the string.
                collapsed = collapsed.replace("\n", "\\n")
                parts.append(f'msgid "{collapsed}"\nmsgstr ""')
        return "\n\n".join(parts) + "\n"

    @staticmethod
    def _split_entries(snippet: str, max_chars: int = 6000) -> list[str]:
        """Split a snippet of msgid/msgstr pairs into chunks on entry boundaries."""
        entries = re.split(r"\n{2,}", snippet.strip())
        chunks: list[str] = []
        current: list[str] = []
        current_chars = 0

        for entry in entries:
            entry_chars = len(entry)
            if current_chars + entry_chars > max_chars and current:
                chunks.append("\n\n".join(current) + "\n")
                current = []
                current_chars = 0
            current.append(entry)
            current_chars += entry_chars

        if current:
            chunks.append("\n\n".join(current) + "\n")

        return chunks if len(chunks) > 1 else [snippet]

    async def _translate_chunks(self, chunks: list[str]) -> list[str] | None:
        """Translate *chunks* concurrently with per-chunk retries.

        Returns a list of translated strings (same length as *chunks*), with
        ``None`` for chunks that failed after all retries.  Returns ``None``
        only if *every* chunk failed.
        """
        total = len(chunks)
        sem = asyncio.Semaphore(self.max_concurrent)

        async def do_chunk(idx: int) -> tuple[int, str | None]:
            async with sem:
                info = f"chunk {idx + 1}/{total}"
                for attempt in range(3):
                    try:
                        result = await self._call_api(chunks[idx], chunk_info=info)
                        if result is not None:
                            return (idx, result)
                    except Exception:
                        if attempt < 2:
                            await asyncio.sleep(2)
                            continue
                    if attempt < 2:
                        await asyncio.sleep(2)
                print(f"\n    Chunk {idx + 1} failed after 3 attempts", flush=True)
                return (idx, None)

        print(f"({total} chunks, {self.max_concurrent} parallel)", end=" ", flush=True)
        results = await asyncio.gather(*[do_chunk(i) for i in range(total)])

        translated: list[str | None] = [None] * total
        failed = 0
        for idx, chunk_text in results:
            if chunk_text is not None:
                translated[idx] = chunk_text.strip("\n")
            else:
                failed += 1

        if failed == total:
            return None  # every chunk failed
        return translated

    @staticmethod
    def _merge_translations(po, untranslated: list[POEntry], translated_snippet: str) -> int:
        """Parse translated snippet and merge msgstr values back into *po*.

        Returns the number of entries that were successfully merged.
        If zero entries could be merged, the translation is considered failed.
        """
        try:
            translated_po = pofile(translated_snippet)
        except Exception as e:
            print(f"\n    Parse error in translated snippet: {e}")
            # Print the first and last 200 chars to help debug.
            preview = translated_snippet[:200] + " ... " + translated_snippet[-200:]
            print(f"    Snippet preview: {preview}")
            return 0

        translated_map: dict[str, str] = {}
        for entry in translated_po:
            if entry.msgid and entry.msgstr:
                translated_map[entry.msgid] = entry.msgstr

        merged = 0
        for entry in untranslated:
            if entry.msgid in translated_map:
                entry.msgstr = translated_map[entry.msgid]
                merged += 1
            else:
                # Exact match failed — try fuzzy matching.
                matched = POTranslator._fuzzy_match(entry.msgid, translated_map)
                if matched is not None:
                    entry.msgstr = translated_map[matched]
                    merged += 1
                    print(f"\n    Fuzzy-matched: {entry.msgid[:60]}...")
                else:
                    # If there's only one untranslated entry and all
                    # exact/fuzzy matches failed, try best-effort: check
                    # if the API returned a single entry whose msgid looks
                    # like a translation (different from the original
                    # msgid but with a non-empty msgid).  The API likely
                    # "translated" the msgid itself.
                    if len(untranslated) == 1:
                        if translated_map:
                            first_key = next(iter(translated_map))
                            entry.msgstr = translated_map[first_key]
                            merged += 1
                            print(f"\n    Best-effort match (only entry): {entry.msgid[:60]}...")
                        else:
                            # translated_map is empty because all entries
                            # have empty msgstr.  Check if parsed entries
                            # have a non-empty msgid (API put translation
                            # into msgid) and take that as msgstr.
                            for pe in translated_po:
                                if pe.msgid and not pe.msgstr:
                                    entry.msgstr = pe.msgid
                                    merged += 1
                                    print(
                                        f"\n    Best-effort (API returned translation as msgid): {entry.msgid[:60]}..."
                                    )
                                    break
                            if not merged:
                                print(f"\n    Missing translation for: {entry.msgid[:60]}...")
                    else:
                        print(f"\n    Missing translation for: {entry.msgid[:60]}...")

        return merged

    @staticmethod
    def _fuzzy_match(msgid: str, translated_map: dict[str, str]) -> str | None:
        """Try to find *msgid* in *translated_map* using normalized comparison.

        Normalizes both sides by collapsing whitespace and stripping trailing
        newlines, then returns the key from *translated_map* that matches, or
        None.
        """
        norm_orig = _normalize_msgid(msgid)
        for key in translated_map:
            if _normalize_msgid(key) == norm_orig:
                return key
        return None

    @staticmethod
    def _clean_response(response: str) -> str:
        response = response.strip()
        if response.startswith("```"):
            lines = response.split("\n")
            lines = lines[1:]
            while lines and lines[-1].strip() == "```":
                lines.pop()
            response = "\n".join(lines).strip()

        # Fix API returning ``msgstr "..."`` instead of ``msgid "..."``
        # for single-line entries.
        if 'msgid "' not in response and 'msgstr "' in response:
            response = response.replace('msgstr "', 'msgid "', 1)

        # Detect when API returns plain translated text instead of PO
        # format (e.g. a bare list of "- ..." lines).  Return an empty
        # string so the caller retries with smaller chunks.
        if 'msgid "' not in response and 'msgstr "' not in response:
            return ""

        return response


def validate_coverage(files_arg: str, ignore_error: bool = False) -> int:
    """Check that every msgstr in the given PO files is non-empty.

    Prints a per-file summary and returns 0 when all files pass,
    1 when any file has untranslated entries (unless *ignore_error* is True,
    in which case untranslated entries only produce warnings and the exit
    code is always 0).
    """
    file_list = [f.strip() for f in files_arg.split(",") if f.strip()]
    total_entries = 0
    untranslated = 0
    failed_files: list[str] = []

    for fp in file_list:
        path = Path(fp)
        if not path.exists():
            print(f"  WARN: {fp} not found, skipping")
            continue
        try:
            po = pofile(str(path))
        except Exception as e:
            print(f"  ERROR: cannot parse {fp}: {e}")
            failed_files.append(fp)
            continue

        empty = [entry for entry in po if entry.msgid and not entry.msgstr and not entry.obsolete]
        file_entries = len([e for e in po if e.msgid and not e.obsolete])
        total_entries += file_entries
        untranslated += len(empty)

        if empty:
            label = "WARN" if ignore_error else "FAIL"
            print(f"  {label}: {path.name} — {len(empty)}/{file_entries} untranslated")
            for e in empty[:5]:
                preview = e.msgid[:80].replace("\n", "\\n")
                print(f'         msgid="{preview}..."')
            if len(empty) > 5:
                print(f"         ... and {len(empty) - 5} more")
            failed_files.append(fp)
        else:
            print(f"  OK:   {path.name} — {file_entries}/{file_entries} translated")

    print(
        f"\nCoverage: {total_entries - untranslated}/{total_entries} translated "
        f"({untranslated} missing) in {len(file_list)} file(s)"
    )
    if ignore_error:
        if failed_files:
            print("Validation errors ignored (--ignore-validation-error).")
        return 0
    return 1 if failed_files else 0


async def async_main():
    parser = argparse.ArgumentParser(description="PO File Translator (DeepSeek)")
    parser.add_argument("--files", required=True, help="Comma-separated PO file paths")
    parser.add_argument("--output-json", default=os.getenv("OUTPUT_JSON", "/tmp/translation_results.json"))
    parser.add_argument("--api-key", default=os.getenv("DEEPSEEK_API_KEY"))
    parser.add_argument("--max-concurrent", type=int, default=5)
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate translation coverage, do not translate",
    )
    parser.add_argument(
        "--ignore-validation-error",
        action="store_true",
        help="When used with --validate-only, print warnings instead of failing on untranslated entries. "
        "When used without --validate-only, translation failures do not cause a non-zero exit code.",
    )
    args = parser.parse_args()

    if args.validate_only:
        return validate_coverage(args.files, ignore_error=args.ignore_validation_error)

    api_key = args.api_key or os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        print("Error: DEEPSEEK_API_KEY not set")
        return 1

    file_list = [f.strip() for f in args.files.split(",") if f.strip()]
    print(f"Translating {len(file_list)} file(s), max_concurrent={args.max_concurrent}")

    translator = POTranslator(api_key=api_key, max_concurrent=args.max_concurrent)
    success_files = []

    for fp in file_list:
        if await translator.translate_file(fp):
            success_files.append(fp)

    results = {
        "success_files": success_files,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_files": len(file_list),
        "success_count": len(success_files),
    }
    out = Path(args.output_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"\nResult: {len(success_files)}/{len(file_list)} translated -> {args.output_json}")
    if args.ignore_validation_error:
        if len(success_files) < len(file_list):
            print("Translation errors ignored (--ignore-validation-error), continuing with successful files.")
        return 0
    return 0 if success_files else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(async_main()))
